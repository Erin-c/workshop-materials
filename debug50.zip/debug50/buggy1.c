// Should print *# ten times and then break on to a new line

#include <stdio.h>

int main(void)
{
    for (int i = 0; i < 10; i++)
        printf("*");
        printf("#");


    printf("\n");
    return 0;
}
